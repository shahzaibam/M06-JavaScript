import { Component } from '@angular/core';

@Component({
  selector: 'app-areaprivada',
  templateUrl: './areaprivada.component.html',
  styleUrls: ['./areaprivada.component.css']
})
export class AreaprivadaComponent {

}
