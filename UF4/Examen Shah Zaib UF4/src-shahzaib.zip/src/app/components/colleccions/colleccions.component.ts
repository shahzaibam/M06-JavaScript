import { Component } from '@angular/core';

@Component({
  selector: 'app-colleccions',
  templateUrl: './colleccions.component.html',
  styleUrls: ['./colleccions.component.css']
})
export class ColleccionsComponent {

}
