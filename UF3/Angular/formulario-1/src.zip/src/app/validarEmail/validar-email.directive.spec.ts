import { ValidarEmailDirective } from './validar-email.directive';

describe('ValidarEmailDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidarEmailDirective();
    expect(directive).toBeTruthy();
  });
});
