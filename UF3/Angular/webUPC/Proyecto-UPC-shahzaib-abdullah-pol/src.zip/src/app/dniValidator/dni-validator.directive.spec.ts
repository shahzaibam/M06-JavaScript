import { DniValidatorDirective } from './dni-validator.directive';

describe('DniValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new DniValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
